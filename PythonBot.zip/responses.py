from datetime import datetime

def sampleResponse(input_text):

    userMessage = str(input_text).lower()

    if userMessage in ("hello", "hi", "whatsup","hey", ""):
        return "Hey! How is it going?"

    if userMessage in ("who are you", "who are you?",):
        return "I am your bot! hahaha "

    if userMessage in ("time", "time?","what is the time?"):
        now = datetime.now()
        dateTime = now.strftime("%d/%m/%y, %H:%M:%S")

        return str(dateTime)


    return "I don't understand what do you mean."

    if userMessage in ("Git", "Github")
        return github.



