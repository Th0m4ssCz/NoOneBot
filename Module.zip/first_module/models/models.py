# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class c:\users\admin2\desktop\my_modules\first_module(models.Model):
#     _name = 'c:\users\admin2\desktop\my_modules\first_module.c:\users\admin2\desktop\my_modules\first_module'
#     _description = 'c:\users\admin2\desktop\my_modules\first_module.c:\users\admin2\desktop\my_modules\first_module'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
