# -*- coding: utf-8 -*-
# from odoo import http


# class C:\users\admin2\desktop\myModules\firstModule(http.Controller):
#     @http.route('/c:\users\admin2\desktop\my_modules\first_module/c:\users\admin2\desktop\my_modules\first_module', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/c:\users\admin2\desktop\my_modules\first_module/c:\users\admin2\desktop\my_modules\first_module/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('c:\users\admin2\desktop\my_modules\first_module.listing', {
#             'root': '/c:\users\admin2\desktop\my_modules\first_module/c:\users\admin2\desktop\my_modules\first_module',
#             'objects': http.request.env['c:\users\admin2\desktop\my_modules\first_module.c:\users\admin2\desktop\my_modules\first_module'].search([]),
#         })

#     @http.route('/c:\users\admin2\desktop\my_modules\first_module/c:\users\admin2\desktop\my_modules\first_module/objects/<model("c:\users\admin2\desktop\my_modules\first_module.c:\users\admin2\desktop\my_modules\first_module"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('c:\users\admin2\desktop\my_modules\first_module.object', {
#             'object': obj
#         })
