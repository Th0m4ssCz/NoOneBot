# -*- coding: utf-8 -*-
# from odoo import http


# class C:\users\admin2\desktop\myModules(http.Controller):
#     @http.route('/c:\users\admin2\desktop\my_modules/c:\users\admin2\desktop\my_modules', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/c:\users\admin2\desktop\my_modules/c:\users\admin2\desktop\my_modules/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('c:\users\admin2\desktop\my_modules.listing', {
#             'root': '/c:\users\admin2\desktop\my_modules/c:\users\admin2\desktop\my_modules',
#             'objects': http.request.env['c:\users\admin2\desktop\my_modules.c:\users\admin2\desktop\my_modules'].search([]),
#         })

#     @http.route('/c:\users\admin2\desktop\my_modules/c:\users\admin2\desktop\my_modules/objects/<model("c:\users\admin2\desktop\my_modules.c:\users\admin2\desktop\my_modules"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('c:\users\admin2\desktop\my_modules.object', {
#             'object': obj
#         })
